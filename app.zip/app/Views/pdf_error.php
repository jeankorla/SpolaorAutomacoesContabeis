<!-- pdf_error.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Erro</title>
</head>
<body>
    <h1>Erro ao converter PDF para texto</h1>
    
    <div class="error"><?= $error ?></div>
</body>
</html>
