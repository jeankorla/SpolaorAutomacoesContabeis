<!DOCTYPE html>
<html>
<head>
  <title>Upload de PDF</title>
  <style>
  body {
  background-color: #eee;
}

/* === Wrapper Styles === */
#FileUpload {
  display: flex;
  justify-content: center;
}
.wrapper {
  margin: 30px;
  padding: 10px;
  box-shadow: 0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);
  border-radius: 10px;
  background-color: white;
  width: 615px;
}

/* === Upload Box === */
.upload {
  margin: 10px;
  height: 85px;
  border: 8px dashed #e6f5e9;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 5px;
}
.upload p {
  margin-top: 12px;
  line-height: 0;
  font-size: 22px;
  color: #0c3214;
  letter-spacing: 1.5px;
}
.upload__button {
  background-color: #e6f5e9;
  border-radius: 10px;
  padding: 0px 8px 0px 10px;
}
.upload__button:hover {
  cursor: pointer;
  opacity: 0.8;
}


/* === Uploaded Files === */
.uploaded {
  width: 375px;
  margin: 10px;
  background-color: #e6f5e9;
  border-radius: 10px;
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
}
.file {
  display: flex;
  flex-direction: column;
}
.file__name {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: baseline;
  width: 300px;
  line-height: 0;
  color: #0c3214;
  font-size: 18px;
  letter-spacing: 1.5px;
}
.fa-times:hover {
  cursor: pointer;
  opacity: 0.8;
}
.fa-file-pdf {
  padding: 15px;
  font-size: 40px;
  color: #0c3214;
}

/* === Botão === */

.button{
  position:relative;
  display:inline-block;
  margin:20px;
}

/* Adicione essa classe à div pai do botão */
.button-container {
  display: flex;
  justify-content: center; /* Centraliza horizontalmente */
  align-items: center; /* Centraliza verticalmente */
}

.button a{
  color:white;
  font-family:Helvetica, sans-serif;
  font-weight:bold;
  font-size:16px;
  text-align: center;
  text-decoration:none;
  background-color:#1F628E;
  display:block;
  position:relative;
  padding:20px 40px;
  
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  text-shadow: 0px 1px 0px #000;
  filter: dropshadow(color=#000, offx=0px, offy=1px);
  
  -webkit-box-shadow:inset 0 1px 0 #FFE5C4, 0 10px 0 #0E415F;
  -moz-box-shadow:inset 0 1px 0 #FFE5C4, 0 10px 0 #0E415F;
  box-shadow:inset 0 1px 0 #FFE5C4, 0 10px 0 #0E415F;
  
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
}

.button a:active{
  top:10px;
  background-color:#0E415F;
  
  -webkit-box-shadow:inset 0 1px 0 #FFE5C4, inset 0 -3px 0 #1F628E;
  -moz-box-shadow:inset 0 1px 0 #FFE5C4, inset 0 -3pxpx 0 #1F628E;
  box-shadow:inset 0 1px 0 #FFE5C4, inset 0 -3px 0 #1F628E;
}

.button:after{
  content:"";
  height:100%;
  width:100%;
  padding:4px;
  position: absolute;
  bottom:-15px;
  left:-4px;
  z-index:-1;
  background-color:#0E415F;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
}
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark mb-4" style="background-color:  #024A7F;">
    <div class="container-fluid navbar-container">
      <a class="navbar-brand" href="<?= base_url('base/index') ?>">
          <img class="img-fluid" src="<?= base_url('img/logo-lado.svg') ?>" alt="Logolado">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <!-- Itens de navegação -->
        </ul>
        <!-- Formulário de pesquisa -->
      </div>
    </div>
  </nav>

  <div id="FileUpload">
    <div class="wrapper">
      <h1>Upload de PDF</h1>

      <!-- Contador de arquivos enviados -->
      <div id="fileCounter">Arquivos selecionados: 0</div>

      <?php if (session()->getFlashdata('error')): ?>
        <div class="error"><?= session()->getFlashdata('error') ?></div>
      <?php endif; ?>

      <?= form_open_multipart('base/convertPdfToText', ['class' => 'upload', 'id' => 'fileUploadForm']) ?>
        <p>Envie seus arquivos
          <span class="upload__button">
            <input type="file" name="pdf_file[]" id="fileInput" multiple style="display:none;">
            Procurar
          </span>
        </p>
        <!-- Botão para enviar os arquivos -->
        
      <?= form_close() ?>
              <div ontouchstart="" class="button-container">
                  <div class="button">
                    <a id="submitBtn" href="#">Enviar</a>
                  </div>
                </div>
      <!-- Loop through uploaded files -->
      <?php if (!empty(session()->get('uploaded_files'))): ?>
        <?php foreach(session()->get('uploaded_files') as $file): ?>
          <div class="uploaded">
            <i class="far fa-file-pdf"></i>
            <div class="file">
              <div class="file__name">
                <p><?= $file ?></p>
                <i class="fas fa-times"></i>
              </div>
              <div class="progress">
                <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" style="width:100%"></div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>


<script>
  var fileInput = document.querySelector('#fileInput');
  var fileCounter = document.querySelector('#fileCounter');
  var form = document.querySelector('#fileUploadForm');

  // Atualizar o contador quando arquivos forem selecionados
  fileInput.addEventListener('change', function() {
    fileCounter.textContent = 'Arquivos selecionados: ' + fileInput.files.length;
  });

  // Enviar o formulário ao clicar no botão
  document.querySelector('#submitBtn').addEventListener('click', function(e) {
  // Verifique se algum arquivo foi selecionado
  if (fileInput.files.length == 0) {
    alert('Nenhum arquivo selecionado');
    e.preventDefault(); // Evita que o formulário seja enviado
  } else {
    form.submit();
  }
});

  // Clique no botão de upload para selecionar arquivos
  document.querySelector('.upload__button').addEventListener('click', function() {
    fileInput.click();
  });
</script>